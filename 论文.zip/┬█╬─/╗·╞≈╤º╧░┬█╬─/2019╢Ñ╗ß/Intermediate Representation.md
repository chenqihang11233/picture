* DeepBase: Deep Inspection of Neural Networks（SIGMOD）
  * 定义一个神经网络的表示，进而优化 比Python实现快72x

* An End-to-End Automatic Cloud Database Tuning System Using Deep Reinforcement Learning(SIGMOD)
  * 强化学习对云数据库的调优，李国良

* SkinnerDB: Regret-Bounded Query Evaluation via Reinforcement Learning（SIGMOD）
  * 强化学习应用在查询估计
* **QTune: A Query-Aware Database Tuning System with Deep Reinforcement Learning**
  * 利用深度强化学习调优数据库
* Automatic Database Management System Tuning Through Large-scale Machine Learning
  * 根据大规模机器学习调优数据库

* MNC: Structure-Exploiting Sparsity Estimation for Matrix Expressions(SIGMOD)
  * 矩阵的稀疏性估计新方法(Matrix Non-zero Count)，精确度高，开销低

* DistME: A Fast and Elastic Distributed Matrix Computation Engine using GPUs(SIGMOD)
  * 分布式矩阵乘法方法降低通信代价，对GPU也适用

* **PS2: Parameter Server on Spark**	
  * 在本文中，我们找出了spark mllib效率低下的原因，并通过在spark之上构建参数服务器来解决这个问题
    * DCV 垂直分区行存储
    * 多个Parameter servers

* An Experimental Evaluation of Large Scale GBDT Systems（VLDB）

  <img src="../../t图片/1570601447621.png" alt="1570601447621" style="zoom:50%;" />

  * 针对Gradient boosting decision tree (GBDT ）算法 的垂直分区行存储.
  * 对于高维特征垂直分区可以避免网络和内存开销
  * 水平分区更适合低维大量实例
  * 对于上述两种都是行存储效率更高

* **ColumnML: Column-Store Machine Learning with On-The-Fly Data Transformation**

  * 列存数据库集成机器学习算法

* **An Intermediate Representation for Optimizing Machine Learning Pipelines**(VLDB)
  * *针对机器学习流水线分别优化的问题，即预处理部分（关系代数和UDF）优化和机器学习算法即训练过程部分优化（线性代数和迭代）各自优化。提出一个影响整个程序的方法，算子下推融合，提供特定领域算子的语义，并优化ML算法的数据访问和交叉验证*。

* FlexPS: Flexible Parallelism Control in Parameter Server Architecture 
  * 应对动态负载，将迭代过程映射为多阶段执行过程，stage之间的并行度是独立的：可根据batch大小自动调整并行度，当batch很小时将工作线程放在一台worker上，单机训练更高效
* **Helix: Holistic Optimization for Accelerating Iterative Machine Learning**
  * 加速机器学习算法中的迭代，通过重用(Max-flow)和cache（NP-hard）和适当的重新计算中间体

- Hyper Dimension Shuffle: Efficient Data Repartition at Petabyte Scale in SCOPE（VLDB）

- Adaptive Deep Reuse: Accelerating CNN Training on the Fly(ICDE)

- **MLlib\*: Fast Training of GLMs Using Spark MLlib（ICDE）**

  - pattern of model update and pattern of communication 
  - model averaging and AllReduce 

- SketchML: Accelerating Distributed Machine Learning with Data Sketches（SIGMOD）

- On Optimizing Operator Fusion Plans for Large-Scale Machine Learning in SystemML（VLDB）

  算子融合技术，优化线性代数

- The BUDS Language for Distributed Bayesian Machine Learning

- Ray: A Distributed Framework for Emerging AI Applications

- Project Adam: Building an Efficient and Scalable Deep Learning Training System

- **Scaling Distributed Machine Learning with the Parameter Server**

- **A Distributed Computing Platform for fMRI Big Data Analytics**

- **HDM: A Composable Framework for Big Data Processing**

- **Petuum: A New Platform for Distributed Machine Learning on Big Data.**

- BigDL: A Distributed Deep Learning Framework for Big Data 